from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),  
    path('team/', views.team, name='team'),
    path('instagram/', views.instagram, name='instagram'),  
    path('details/<int:player_id>/', views.details, name='details'),
]
