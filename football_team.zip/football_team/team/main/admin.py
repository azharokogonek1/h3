from django.contrib import admin
from .models import(player)


admin.site.register(player)
